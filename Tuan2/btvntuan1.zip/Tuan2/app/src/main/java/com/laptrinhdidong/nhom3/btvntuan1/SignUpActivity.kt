package com.laptrinhdidong.nhom3.btvntuan1

import android.databinding.DataBindingUtil
import android.os.Bundle
import android.os.PersistableBundle
import android.support.v7.app.AppCompatActivity
import android.widget.Toast
import com.laptrinhdidong.nhom3.btvntuan1.databinding.Nhom3QuocSignupBinding

class SignUpActivity : AppCompatActivity()  {
    private lateinit var binding: Nhom3QuocSignupBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding=DataBindingUtil.setContentView(this,R.layout.nhom3_quoc_signup)
        binding.btnSignup123.setOnClickListener {
            Toast.makeText(this,"aaa",Toast.LENGTH_SHORT).show();
        }
    }
}